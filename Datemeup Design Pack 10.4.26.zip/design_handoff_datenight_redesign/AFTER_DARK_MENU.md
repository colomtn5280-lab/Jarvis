# After Dark menu · Romantic + Spicy (40 items)

The seed data is in `after_dark_menu.json` (same content, ready to import). Each item: category AFTER_DARK, adTier ROMANTIC or SPICY, source SEED.

## Romantic (20)
- **R01 🍝 Cook-off for two** · Home · 2h
  Same ingredients, two dishes, one judge each. Loser does dishes.
- **R02 🔭 Blanket and the sky** · Out · 3h
  Drive somewhere dark, bring a thermos, name the constellations wrong.
- **R03 💆 Couples massage class** · Out · 90m
  Learn it once, use it forever. Most studios run a 90-minute intro.
- **R04 🏨 Staycation** · Out · 1 night
  A hotel 10 minutes away. Late checkout, room service breakfast.
- **R05 🌅 Sunrise drive** · Out · 2h
  Alarm at 5, coffee in the car, watch it come up from the hill.
- **R06 ✉️ Letter swap** · Home · 1h
  Write each other a letter, read them out loud over a drink.
- **R07 💃 Kitchen dance lesson** · Home · 45m
  One YouTube tutorial, one song, bare feet on tile.
- **R08 🛁 Bath, playlist, no phones** · Home · 1h
  Candles, a shared playlist, a hard stop on screens.
- **R09 🧺 Rooftop picnic** · Out · 2h
  Sandwiches and a bottle up on the roof or the fire escape.
- **R10 🔁 Recreate the first date** · Out · 3h
  Same place if it still exists, same order, better conversation.
- **R11 🥐 Slow breakfast in bed** · Home · 1h
  One of you cooks, the other stays. Swap next week.
- **R12 🎨 Wine and paint at home** · Home · 2h
  Two canvases, one bottle, paint each other. No talent required.
- **R13 🧖 Spa afternoon** · Out · 3h
  Sauna, steam, plunge. Go on a weekday if you can.
- **R14 🚗 Drive-in movie** · Out · 3h
  Blankets, snacks, the back seat down.
- **R15 📚 Bookshop swap** · Out · 2h
  Pick a book for each other, read the first chapter together at the cafe.
- **R16 🫕 Fondue night** · Home · 2h
  Cheese or chocolate. Long forks, longer conversation.
- **R17 🌙 Moonlit walk** · Out · 1h
  The usual route, at midnight, holding hands.
- **R18 🍽️ No-phones dinner** · Out · 2h
  Book somewhere nice. Phones stay at home, not in pockets.
- **R19 ✈️ Plan the dream trip** · Home · 90m
  Open the map, pick a country, build the itinerary you'll take one day.
- **R20 🫙 Memory jar night** · Home · 1h
  Write 20 favourite moments on slips, pull them one by one.

## Spicy (20)
- **S01 📝 Yes / No / Maybe list** · Home · 1h
  Each fill one in privately, then compare only the overlaps.
- **S02 👗 Outfit surprise** · Home · evening
  One of you picks what the other wears tonight. Sealed envelope.
- **S03 🫒 Massage, oils, lights low** · Home · 90m
  Warm oil, one long playlist, no clock.
- **S04 ❓ 20 questions, adults only** · Home · 1h
  Take turns; honest answers only. Pass is always allowed.
- **S05 🙈 Blindfold taste test** · Home · 45m
  Five small bites, one blindfold, guess wrong and owe a favour.
- **S06 🎲 The dare jar** · Home · 1h
  Write ten dares each, keep it playful, draw three.
- **S07 💿 One song, slow dance** · Home · 20m
  Lights off, one song on repeat, see where it goes.
- **S08 🗝️ Hotel, no plans** · Out · 1 night
  Check in at 6. Do not leave the room.
- **S09 🗺️ Love-note scavenger hunt** · Home · 1h
  Notes hidden around the flat, each one a clue. Last one is in the bedroom.
- **S10 🚿 Shower together** · Home · 30m
  Simple. Hot water, no rush.
- **S11 🍸 Strangers at the bar** · Out · 2h
  Arrive separately. Meet like it's the first time. Pick each other up.
- **S12 🛍️ Browse the toy shop** · Out · 1h
  Together, online or in person. Nothing has to come home.
- **S13 🃏 Adults-only game night** · Home · 2h
  A couples card game, a bottle, a rule that you finish the deck.
- **S14 🕯️ Bath for two** · Home · 1h
  Candles, a glass each, a hard stop on talking about work.
- **S15 🥂 Dress code: robe** · Home · evening
  Dinner in, ordered or cooked, robes only.
- **S16 🥞 Morning after breakfast** · Home · 2h
  Order in, stay in bed until it arrives, and after.
- **S17 💭 One fantasy each** · Home · 45m
  Share one, listen to one. No commentary until both are out.
- **S18 📸 Photo booth for two** · Home · 30m
  Your phones, your rules. Stays on your devices.
- **S19 🌜 Midnight snack in bed** · Home · 30m
  Something you can eat with your fingers. Crumbs are fine.
- **S20 👃 Five-senses night** · Home · 2h
  One thing to taste, touch, smell, hear and see. Take turns leading.
