# DateMeUp brand assets (logo 5a, Oct 4 2026)

Symbol: two people leaning in (teal + lime), an "up" chevron above. Wordmark: "datemeup", Sora 800, tracking -0.05em. Source board: DateMeUp Rebrand.dc.html #5a.

- icon-ios-1024.svg / .png, icon-512.png: app icon, teal tile #0E8C8C with white + lime figures (chosen). icon-ios-1024-ink-alt.svg: ink-tile alternative, not in use.
- icon-android-foreground / background / monochrome-432.svg: adaptive icon layers (glyph inside the 66dp safe zone).
- mark-teal.svg (light backgrounds), mark-white.svg (dark backgrounds), mark-mono-ink.svg (one colour).
- lockup-horizontal-light/dark.svg, lockup-stacked-light.svg: outline the text before shipping.
- splash-1284x2778.svg: teal background, centre-crop for Android.
- mark-68.png: email header mark on a teal rounded tile.

Colours: teal #0E8C8C (dark mode #2FC4C1), lime #7CB518 (#A8E04B), ink #101820. Clear space = one head diameter. Minimum: 20px symbol, 110px lockup. Don't rotate the mark.
