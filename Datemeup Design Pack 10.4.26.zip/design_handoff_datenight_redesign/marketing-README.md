# Together Plans — Marketing & Advertising Plan
Founder-run · under $1k/month · US + UK/CA/AU · soft launch in ~6 weeks, full launch at ~3 months · app is free · faceless, product-led video

Visual pages live next to this file: `Marketing Hub.dc.html` (index), then one page per channel family. Assets are packaged by app (iOS / Android / Web) and channel in the Hub matrix.

## 1. Positioning
- One line: **Plan together. Go together.**
- Problem hook: **47 messages later, still no plan.** Every group chat has this thread; Together Plans ends it in three taps: propose 3–5 options → everyone votes → it locks in.
- Audiences, in order: couples (primary), friend groups, families. Marketing leads with couples because the pair loop is fastest (one invite = one activation).
- After Dark is a secondary hook: mentioned tastefully in couples channels ("a private category for just the two of you"), never in store screenshots 1–3, never in print. App rating: 16+ iOS / Mature 17+ Play.
- Voice: friendly, decisive, light. Specific beats clever. No couple stereotypes, no "spice up your marriage" clichés.

## 2. What makes it spread (loops before channels)
1. **Pair loop.** A group is useless alone, so every activation is an invite. KPI: *pair rate* = % of new users whose first invite is accepted within 48h. Target 45% at soft launch, 60% at full launch.
2. **Share Cards loop.** Every decided plan can become a 9:16 card for iMessage/WhatsApp/IG Story with a small "made with Together Plans" footer and a deep link (`togetherplans.app/p/:id`). Target 0.4 cards sent per decided plan; every card is an ad the user chose to send.
3. **Vote-without-install.** Recipients of a vote link open an iOS App Clip / Play Instant / web vote page and vote before installing. Cuts the "my partner won't download an app" objection. Engineering ask, highest-leverage item in this plan.
4. **Screenshot loop.** The "47 messages later" campaign: users post their own worst planning threads (blurred) next to the Together Plans result. UGC that explains the product in one image.
5. **Free web tool.** `togetherplans.app/decide`: a no-signup "we can't decide" picker (paste 3 options, send link, both vote). SEO magnet + trial of the core mechanic + soft path to the app.

## 3. Channels, packaged by app
| Channel | iOS | Android | Web |
|---|---|---|---|
| Store listing + ASO | App Store copy, 6 screenshots, keywords, in-app events | Play copy, 8 screenshots, feature graphic, pre-registration | n/a |
| Short video (TikTok/Reels/Shorts) | Screen-recorded on iPhone frame | Same scripts, Android frame for Play-linked posts | Clips embedded on landing |
| Instagram | Story Share Cards, carousel ads | Same | Link-in-bio landing |
| Reddit + communities | r/relationships-adjacent, r/dating_advice (rules permitting), r/AskSF etc. | r/androidapps launch post | r/SideProject, r/webdev |
| In-app referral + Share Cards | Share sheet, App Clip | Share sheet, Play Instant | Copy link + PNG |
| Email lifecycle | Onboarding, pair nudge, first-decision, win-back | Same | Waitlist + launch |
| SEO landing pages | Smart App Banner | Play badge | 12 intent pages + /decide tool |
| Product Hunt | Screenshots + App Clip demo | Play link | Primary link is the web app |
| Local print | QR → App Store | QR → Play | QR → /decide (auto-routes) |
| Partnerships | Wedding vendors, climbing gyms, cinemas | Same | Co-branded pages |
| Podcast / newsletter | Promo code = referral link | Same | UTM landing |
| Press / PR | Press kit, App Store feature pitch | Play feature pitch | Founder story |
| Paid tests (small) | Apple Search Ads $5/day, brand + "date night ideas" | Google App Campaign $5/day | Reddit promoted post $50 test |

## 4. Budget (per month, ceiling $1,000)
- Paid social + search tests: $300 (Apple Search Ads $150, Play $100, Reddit $50)
- Creator seeding: $200 (four $50 date-night gift cards to micro-creators, 5–30k followers, in exchange for one honest video)
- Newsletter / podcast micro-sponsorships: $200 (one slot/month in a couples or productivity newsletter under 20k subs)
- Print: $100 (500 table cards, 200 stickers, 100 flyers per city, rotating)
- Tools: $100 (scheduler, link shortener with UTM, QR codes, PH launch assets)
- Reserve: $100 (boost whatever worked)
Organic channels (video, Reddit, SEO, referral, PR) cost time, not money: budget ~10 hours/week founder time.

## 5. Calendar
**Weeks 1–2 (now):** waitlist landing live; `/decide` tool live; store listings drafted; TestFlight + Play internal testing; press kit written; 20 short videos scripted, 8 shot; Reddit account warmed (helpful comments, no links).
**Weeks 3–6 (soft launch, Bay Area + waitlist):** invite 300 waitlisters in 3 waves; measure pair rate and D7; ship Share Cards + App Clip; first 3 table-card venues; first newsletter slot; weekly video cadence starts (3/week).
**Weeks 7–8 (pre-launch):** press outreach (embargo for launch day); PH assets; creator seeding round 1; SEO pages published; email launch sequence queued.
**Week 9 (full launch):** Product Hunt Tuesday; press embargo lifts; "47 messages later" campaign starts; Apple Search Ads on; Reddit launch posts in 4 subs; store "in-app event".
**Weeks 10–12:** double down on the 2 channels with lowest CAC; wedding-vendor outreach for spring; UK/CA/AU store localisation (spelling, date formats, local venue seed data); second creator round.
**Months 4–6:** partnerships at scale, campus pilots (Sept intake), SEO compounding, print in 4 cities, quarterly PR moment (Valentine's, wedding season, back-to-school).

## 6. KPIs and targets (full launch, month 3)
- Installs: 5,000 total; 60% iOS / 30% Android / 10% web-only
- Pair rate 60%; K-factor ≥ 0.5 (invites per user × accept rate)
- D7 retention 30%, D30 20%
- Decided plans per active group per month: 2
- Share Cards per decided plan: 0.4; card → visit → install 8%
- Blended CAC ≤ $1.50; paid-channel CAC ≤ $4 or the channel is cut
- Store conversion (listing view → install) ≥ 30%

## 7. Viral playbooks (details in Playbooks.dc.html)
1. **47 Messages Later** — UGC screenshot campaign, hashtag, weekly "worst thread" feature, template in-app.
2. **The Decide Link** — free web tool, no signup, shareable result, IG-story sized.
3. **Vote Before You Install** — App Clip / Play Instant vote page; every invite becomes a trial.
4. **Share Card Sundays** — weekly template drop; IG story reshare mechanic; templates only unlockable by sending one.
5. **Wedding Registry for Date Nights** — couples add "12 date nights" to their wedding site; guests fund one each; vendor cross-promo.
6. **Campus Roommate Pact** — Sept intake; RA/orientation partnerships; "first 30 days" group challenge.

## 8. Traditional, low-cost
- Cafe/bar table cards: "Can't decide? Scan." QR routes by device to store or `/decide`. Venue gets a Discover listing.
- Sticker sheets: "47 messages later" and the calendar-heart mark; laptop and water-bottle sizes; handed out at climbing gyms, cinemas, farmers markets.
- Flyer for wedding fairs and vendor lobbies (photographers, planners, florists).
- Cinema pre-show slide (local independents often sell slides for $50–150/month): "Deciding on the movie took longer than the movie."
- Community radio/campus radio 15-second read (free PSA slots exist for local startups more often than expected).
- Postcards in the box for partner venues' gift cards.

## 9. Measurement stack (free tier)
- UTM on every link; one short domain (`dtnt.app/…`) with per-channel slugs; QR codes generated per venue.
- Store: App Store Connect + Play Console sources; custom product pages per campaign (iOS) and custom store listings (Play).
- In-app events: `invite_sent`, `invite_accepted`, `plan_decided`, `share_card_sent`, `card_link_opened`, `vote_without_install`.
- Weekly one-page dashboard: installs by source, pair rate, K-factor, CAC by channel, top 3 videos.

## 10. Risks and rules
- Reddit: contribute for 3 weeks before posting; disclose you're the founder; never astroturf.
- After Dark: never in ads targeted under 18; keep it out of Play feature graphic and iOS screenshots 1–3; rating 16+.
- Photo attribution: Yelp/TMDB/Places terms apply to any real-venue imagery in ads; use Unsplash-licensed or own photos.
- Localisation: UK/AU spelling in store listings; date formats; local venue seed data before promoting there.
- Faceless video: lean on screen recordings, hands, captions and voiceover; consistency of the "47 messages" motif matters more than polish.
