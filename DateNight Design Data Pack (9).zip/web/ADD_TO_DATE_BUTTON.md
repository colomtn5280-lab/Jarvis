# "Add to Date" button (suggestion cards)

Applies to every suggestion / Discover card on web, iOS and Android.

## Changes
1. **Label:** "+ Add to Plan" → **"Add to Date"** (the "+" is drawn by the style, not typed). Added state reads **"Added"** with a ✓.
2. **Shape:** replace the grey rectangular browser button with the app's bubble button: teal pill with asymmetric radius `23px 17px 23px 17px`, 44px tall, full card width, Sora 700 14px, soft teal shadow.

## Web
```html
<button class="dmu-add" aria-pressed="false">Add to Date</button>
<!-- after tap -->
<button class="dmu-add" aria-pressed="true">Added</button>
```
Styles: `web/add-to-date-button.css`. Remove any default `<button>` border/background on cards.

## iOS / Android (React Native)
- Pressable, height 44, `borderTopLeftRadius 23, borderTopRightRadius 17, borderBottomRightRadius 23, borderBottomLeftRadius 17`
- Background #0E8C8C, text #FFFFFF, Sora_700Bold 14, leading "+" glyph
- Pressed: scale 0.98, background #086B6B
- Added: background #EAF6D3, text #101820, "✓ Added", radii mirrored (17/23/17/23)
- Haptic: light impact on add (iOS), `performHapticFeedback` CONFIRM (Android)

## Card spacing
14px between the distance line and the button; 16px card padding. The button sits at the card bottom (card is a column flex with the button at `margin-top:auto`) so buttons line up across a row.
