# Group detail (/groups/:id) · fix for the live page

Files: `web/group-detail.html` (implement 1:1) and `web/group-detail.css`. Load `dashboard.css`, then `groups.css`, then `group-detail.css`.

The root cause is the same as the other pages: no styles or fonts are loading, and there's no page container.

| Live | Fix |
|---|---|
| "← Groups" link pushed against the left edge | Pill-shaped back link "← Your groups" inside the 1080px container |
| Serif title, a single avatar, "1 member" | Large avatar stack, with a dashed "?" slot for the partner who hasn't joined; Sora 800 title; status line "Couple · 1 member · Erin hasn't joined yet" |
| Blue "+ New Proposal" link floating at the far right | Teal bubble "+ New proposal" button on the same row as the title |
| "RECENT PROPOSALS" cut off at the left edge; map emoji empty state | "Proposals" section label; an empty-state card with three tilted idea cards, "No plans yet. Start one.", and two buttons: New proposal and Browse ideas |
| Five grey browser buttons (EMAIL SMS QR LINK CODE) and a full-width grey "Generate invite" bar | "Invite Erin" card: a segmented control (Link / Email / SMS / QR / Code) that defaults to Link, a box showing the link with a Copy button, a teal "Share invite" button (the native share sheet on mobile), and the expiry note |
| Members list with the ⋯ at the far edge | Members card: blob avatars and roles, the pending invitee shown greyed out with a ⋯ menu to resend or cancel |
| — | "Group settings" link at the bottom of the right column |

Rules:
- Each invite tab swaps the body of the card: Email = email field + Send; SMS = phone field + Send; QR = a 180px QR code + Download; Code = a 6-character code in Sora 800 28px + Copy.
- Once the partner joins, hide the Invite card for couples (groups keep it); the "?" slot becomes their avatar.
- With proposals, replace the empty card with proposal cards (newest first), using the Proposal Detail styles from `DateNight Web.dc.html`.
- Use the group's real name in "Invite {name}" when one is known; otherwise "Invite members".
