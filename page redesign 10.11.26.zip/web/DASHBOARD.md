# Web dashboard (4b) · fix for the live page

**Root cause on datemeup.app/dashboard:** the page has the 4b structure, but none of its styles are applied. The text shows in Times (the Sora / DM Sans font link is missing), the links are browser blue, and Sign out is an unstyled browser button. Load the font `<link>` and `dashboard.css` (or port the rules into your CSS modules) before you change anything else.

Files: `web/dashboard.html` (markup, implement 1:1), `web/dashboard.css` (styles, light and dark).
Design source: `DateMeUp Rebrand.dc.html` #4b.

## What changes vs the live page
| Live | Fix |
|---|---|
| Teal outlined box with "All caught up / No open proposals / Start a new plan" as plain text | Solid teal hero card with sticker radii, a lime "ALL CAUGHT UP ✓" sticker, the heading "What are we doing this weekend?" and a white "+ Start a new plan" bubble button |
| Greeting uses the full name in a serif font | "Good afternoon, {firstName}." in Sora 800 38px; the subline "All caught up. No open proposals." goes underneath |
| Groups shown as dots and bold text | Groups card: blob avatar with initial, name, status line, "Manage" link, and a dashed "+ New group" button |
| Account block: email, ⚙ Settings, grey Sign out bar | Account card: avatar, name and email, then two equal bubble buttons, **Settings** and **Sign out** (red text) |
| Large centred "GET THE APP" block | Slim footer row: legal links on the left, "Vote on the go" and two small store badges on the right |
| Nothing below the hero | "Ideas near you": three Discover cards with photos and the **Add to Date** button |
| Nav pills sit off-centre | Logo on the left, nav pills, then "+ New plan" and a bell on the right, all inside the same 1080px container as the content |

## Layout rules
- One centred container, max 1080px, 32px side padding. The header, the content and the footer all use it, so their edges line up.
- Two columns: `minmax(0,1fr) 300px`, 28px gap. Under 960px the right column moves below the content as two side-by-side cards; under 768px it's a single column and the native bottom dock replaces the top nav.
- Empty state vs active: when the user has open proposals, replace `.dmu-hero` with the proposal cards from `DateNight Web.dc.html` and keep the "Ideas near you" row.
- Names come from the API; truncate long group names with an ellipsis (`.dmu-g-text b`).
- Dark mode via `prefers-color-scheme`. The hero stays teal #0E8C8C in both modes.
