# Your groups (/plans) · fix for the live page

Files: `web/groups.html` (markup, implement 1:1), `web/groups.css`. Load `web/dashboard.css` first: it holds the shared header, buttons, avatars and footer, so every app page should load it.

**Same root cause as the dashboard:** no styles or fonts are loading on this page (Times text, browser-blue links, a grey browser button). The content also runs edge to edge with no container. Load the font link and the CSS first.

## What changes vs the live page
| Live | Fix |
|---|---|
| Content stretches to the full window width with no left padding | Same centred 1080px container as the header and footer |
| Old calendar logo, "DateMeUp" in a serif font | 5a mark plus the "datemeup" wordmark |
| Grey "New group +" button at the far right | Teal bubble "+ New group" button, aligned with the page title |
| Groups are loose text in three wide columns | Group cards (3 per row) with sticker radii: overlapping blob avatars, an "Active" pill, the name, a type and member-count line, and a teal "open plan" row that says what's waiting |
| Blue links for "Active" and the group names | The whole card is the link; Active is a lime pill |
| "1 members" | Correct plurals: "1 member" / "2 members" |
| Dashed "New group" box on its own row | A dashed card that sits in the grid as the last item |
| No filtering | Segmented filter: All · Couples · Friends & family, with counts |

## Rules
- Grid: 3 columns, 2 under 960px, 1 under 768px (the native dock replaces the top nav).
- Card corner shapes repeat every 4 cards (`nth-child(4n…)`), so keep all the cards in one flat list.
- Open-plan row: show the newest open proposal's title and its status ("your vote needed", "waiting on {name}", "decided · Fri 8 PM"). If there's no open plan, show "No plan yet · Start one →" and use `.dmu-pill-quiet` instead of Active for groups inactive for 30+ days.
- Avatars: up to 4 members, then a "+N" avatar.
- Header: the account avatar on the right links to Settings; Sign out stays on the dashboard account card.
