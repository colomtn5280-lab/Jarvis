# Loading states (all pages)

Files: `loading.css` (load after `dashboard.css`), `loading.js` (no dependencies, exposes `DMU.loading`), `loading.html` (live demo, use the Network switch to test).

## Timing rule (applies to every loader)
- Show nothing for the first **300 ms**. Fast responses never flash a loader.
- Once a loader is visible, keep it for at least **500 ms**. It never blinks.
- Loaded content fades and rises in (320 ms, list items staggered 40 ms).
- `prefers-reduced-motion`: logo pulses instead of moving, no shimmer, content fades only.

## One loader: logo 5a, three sizes
The two figures lean in and the chevron hops (1.2 s loop). Decision Oct 17 2026: the logo is used for every loading state; no generic spinners, no skeletons.

| Situation | Size | Call |
|---|---|---|
| First app load, route change | 72 px, full colour, overlay + top progress bar, label names the destination | `DMU.loading.page(task, {label})` |
| Search, Discover, lists, group/proposal data | 56 px, full colour, centred in the content area, which keeps its height | `DMU.loading.region(el, task, render, {label})` |
| Any submit (send proposal, vote, Add to Date, invite, save) | 22 px, single colour (white on teal, teal on ghost) in place of the label, width locked, disabled | `DMU.loading.button(btn, task)` |

Skeletons are still available via `opts.skeleton` but are not used by default.

## Duplicate submissions
- `button()` locks on the first click (no delay) and ignores further clicks until the task settles. It also sets `form.dataset.busy`; check it in submit handlers.
- Server side, still send an idempotency key with proposal/vote/invite requests.
- `region()` tracks request order: if the user searches again, the older response is dropped.

## Accessibility
- Busy buttons get `aria-busy="true"` and an `aria-label` ("Sending…", "Searching…").
- Regions get `aria-busy` while loading and should carry `aria-live="polite"`.
- Overlay is `role="status"` with visible text ("Loading…" or a specific label, e.g. "Opening Friday night…").

## Errors
`region()` renders "That didn't load." with a **Try again** button that reruns the same request. Pass `opts.error(err)` to customise.

## Mobile (Expo)
Same rules. Logo loader = Lottie or Reanimated version of the same motion; skeletons use the card radii `22 30 20 26`.
