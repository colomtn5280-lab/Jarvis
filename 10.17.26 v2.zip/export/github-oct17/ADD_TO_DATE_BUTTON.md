# "Add to Date" button (suggestion cards)

Applies to every suggestion / Discover card on web, iOS and Android.

## Changes
1. **Label:** "+ Add to Plan" → **"Add to Date"** (the "+" is drawn by the style, not typed). Added state reads **"Added"** with a ✓.
2. **Shape:** bubble button with asymmetric radius `23px 17px 23px 17px`, 44px tall, full card width, Sora 700 14px, no shadow.
3. **Colour (Oct 17, option 2c "soft tint"):** pale teal #D9F1F0 with deep teal text #086B6B, so a 30-card grid isn't solid teal. Hover/pressed fills solid teal #0E8C8C with white text. Category label above the name is grey #5D6B76 (class `.dmu-idea-cat`), not teal. Board: `DateMeUp Color Schemes.dc.html` #2c.

## Web
```html
<button class="dmu-add" aria-pressed="false">Add to Date</button>
<!-- after tap -->
<button class="dmu-add" aria-pressed="true">Added</button>
```
Styles: `web/add-to-date-button.css`. Remove any default `<button>` border/background on cards.

## iOS / Android (React Native)
- Pressable, height 44, `borderTopLeftRadius 23, borderTopRightRadius 17, borderBottomRightRadius 23, borderBottomLeftRadius 17`
- Background #D9F1F0, text #086B6B, Sora_700Bold 14, leading "+" glyph (dark: #163A3B / #7FE0DD)
- Pressed: scale 0.98, background #0E8C8C, text #FFFFFF
- Added: background #EAF6D3, text #3F6A06, "✓ Added", radii mirrored (17/23/17/23) (dark: #2A3A1A / #C6EE85)
- Category label: #5D6B76 (dark #93A3AF)
- Haptic: light impact on add (iOS), `performHapticFeedback` CONFIRM (Android)

## Card spacing
14px between the distance line and the button; 16px card padding. The button sits at the card bottom (card is a column flex with the button at `margin-top:auto`) so buttons line up across a row.
