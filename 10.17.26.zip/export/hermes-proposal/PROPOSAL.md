# Proposal detail (/proposals/:id) · fix for the live page

Files: `web/proposal.html` (implement 1:1) and `web/proposal.css`. Load `dashboard.css`, then `groups.css`, then `group-detail.css`, then `proposal.css`.

| Live | Fix |
|---|---|
| "← Back to group" against the left edge, no container | Pill-shaped back link with the group name ("← Date Night with Erin") inside the 1080px container |
| A loose "Open" word next to the title | A tilted amber "VOTING OPEN" sticker above the title; meta line "Sat, Oct 10 · proposed by you · 1 option" |
| Grey "Invite someone to vote" browser button with an emoji | Ghost bubble button aligned with the title row |
| Wide photo card in a half-empty column; the heart is a small grey circle on the photo | Horizontal option cards (photo on the left, details on the right) in the main column; a large 52px blob heart button at the bottom right; category chip and photo credit on the photo |
| "Date / Status / Members" as plain text lines | A small details list at the bottom of the right column (date, group, reminder) |
| A "Vote tally" bar showing 0/1 | **Removed.** Settled decision: hearts stay hidden until everyone has voted. It's replaced by a "Who's voted" card: "0 of 2", a progress bar, each member's state, and an Invite button for anyone who hasn't joined |
| Yellow "Voting is open" bar with a grey Counter-propose button | "Not feeling it?" card: a short explanation, a teal Counter-propose button, and a red-text ghost Cancel proposal button |
| Full-width grey "Cancel proposal" bar | Inside the card above; ask for confirmation before cancelling |
| No way to add options | Dashed "Add another option" row under the options (only for the proposer, while nobody has voted) |

Rules:
- Heart: `aria-pressed` toggles; the voted state is a teal fill with a white heart. Single heart per person. Groups of 4+ also get the veto (long-press / ⋯ menu), per `DateNight Mobile.dc.html` 5a.
- Card corner shapes repeat every 3 cards (`nth-child(3n…)`).
- Who's voted: show "✓" (`.dmu-vote-state.is-in`) for people who have voted, without saying which option they picked.
- Status sticker: `.dmu-status-open` (amber) while voting; `.dmu-status-matched` (lime, "IT'S A MATCH") once the plan locks in, which also swaps the main column for the winner card and the Share Card prompt; `.dmu-status-cancelled` (grey, not rotated).
- Reminder line: the T-24h reminder goes only to people who haven't voted.
- Photos: use the venue or event photo with a credit. Always layer the fallback under it: `background-image:url(photo), linear-gradient(135deg,#086B6B,#0E8C8C)` and `background-color:#0E8C8C`, so a missing or broken image still shows teal with a readable white credit and the category chip.
- Mobile (<768px): option cards stack with the photo on top; the right column moves below the options.
