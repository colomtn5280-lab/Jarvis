# Hermes: web app pages (datemeup.app)

Implement these pages 1:1. Each one has a production `.html` file (markup), a `.css` file (styles) and a `.md` file (what changed and the rules). Open the `.html` files in a browser to see the target.

## 0. Fix this first (it affects every page)
The live pages are unstyled: text falls back to Times, links are browser blue, and buttons are grey browser defaults. Before you rebuild any layout:
1. Add the font link to the app shell `<head>`:
   `<link href="https://fonts.googleapis.com/css2?family=Sora:wght@600;700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">`
2. Load `dashboard.css` globally. It's the shared shell: colour variables (light and dark), header, nav, buttons, avatars, cards and footer.
3. Wrap every page's header, main content and footer in `.dmu-wrap` (centred, max 1080px).

## 1. Pages, in build order
| # | Route | Files | Notes |
|---|---|---|---|
| 1 | Shared shell | `dashboard.css` | Load on every page |
| 2 | `/dashboard` | `dashboard.html`, `DASHBOARD.md` | Empty-state hero, Ideas near you, groups + account rail, slim footer |
| 3 | `/plans` (Your groups) | `groups.html`, `groups.css`, `GROUPS.md` | Group cards, filter, New group card |
| 4 | `/groups/:id` | `group-detail.html`, `group-detail.css`, `GROUP_DETAIL.md` | Avatar header, empty state, Invite card with tabs, Members card |
| 4b | `/proposals/:id` | `proposal.html`, `proposal.css`, `PROPOSAL.md` | Option cards with heart, Who's voted (no tallies), Counter-propose / Cancel card |
| 5 | `/discover` filters | `DISCOVER_FILTERS.md`, `discover-filters.css`, `discover-filters.json` | Blob category tiles + When / How far segments; remove emoji |
| 6 | Suggestion card button | `ADD_TO_DATE_BUTTON.md`, `add-to-date-button.css` | "Add to Date" teal bubble; "✓ Added" state |
| 7 | `/` (landing) | `landing.html`, `README.md` | Marketing landing |

CSS load order per page: `dashboard.css` → page CSS (for `/groups/:id`: `groups.css` then `group-detail.css`; for `/proposals/:id` add `proposal.css` last).

## 2. Shared rules
- **Brand:** logo 5a (two leaning figures + "up" chevron) with the wordmark "datemeup" in Sora 800. SVG is inline in each `.html`; production files are in `brand/`. Replace the old calendar icon everywhere.
- **Colours:** teal #0E8C8C, deep #086B6B, soft #D9F1F0, lime #7CB518, soft #EAF6D3, ink #101820, ink-2 #5D6B76, line #DDE3E8, bg #F4F6F8. Dark mode values are in `dashboard.css` (`prefers-color-scheme`).
- **Type:** Sora 700–800 for headings, buttons and labels; DM Sans for body text.
- **Shape:** asymmetric "sticker" radii on cards and buttons (e.g. `22px 30px 20px 26px`); pills for nav and segmented controls. Only stickers and badges rotate.
- **Buttons:** never ship a browser-default `<button>`. Use `.dmu-btn` with `-primary`, `-light`, `-ghost`, `-dashed` or `-block`.
- **Layout:** two columns `minmax(0,1fr) 300px` where there's a right rail; it stacks under 960px. Under 768px the native bottom dock replaces the top nav (see `DateNight Web.dc.html` mobile frames).
- **Copy:** "1 member" / "2 members" (correct plurals). The suggestion action is "Add to Date". Sign out is a button in the dashboard account card, never a full-width bar.
- **"Get the app":** only in the slim footer row, never as a block in the page body.

## 3. Data hooks
- Greetings use the first name: "Good afternoon, {firstName}."
- Group card status line: newest open proposal + its state ("your vote needed", "waiting on {name}", "decided · Fri 8 PM"), or "No plan yet · Start one →".
- Group detail: show the Invite card until the partner joins (couples); groups keep it. The pending invitee is listed under Members with resend and cancel options.
- Idea cards: Yelp / Google Places photo with an attribution caption; category placeholder when there's no photo.

## 4. Done when
- No serif text and no blue underlined links anywhere in the app.
- Header, content and footer edges line up at every width.
- Light and dark mode both look right.
- 768–960px: no stretched cards (rail cards use `align-items:start`).
